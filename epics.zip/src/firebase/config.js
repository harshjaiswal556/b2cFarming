import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/firestore";
import "firebase/compat/storage";
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
const firebaseConfig = {
  // apiKey: "AIzaSyCggZCcBun0cwNfOWGC2K8pZcgIRWMfqwY",
  // authDomain: "olx-sijeesh.firebaseapp.com",
  // projectId: "olx-sijeesh",
  // storageBucket: "olx-sijeesh.appspot.com",
  // messagingSenderId: "767411886432",
  // appId: "1:767411886432:web:2ef6862afc88f2c423a605",
  // measurementId: "G-4ELNR9DJHL"
  apiKey: "AIzaSyBbLb3dnh8brjiCJnGrcZMcCl06wAYvrek",
  authDomain: "my-first-project-37eb6.firebaseapp.com",
  projectId: "my-first-project-37eb6",
  storageBucket: "my-first-project-37eb6.appspot.com",
  messagingSenderId: "678929199980",
  appId: "1:678929199980:web:9dec9f9ad30f02c1c1f949",
  measurementId: "G-FJMVFT8XPJ",
};

export const Firebase = firebase.initializeApp(firebaseConfig); //named export
// const app = initializeApp(firebaseConfig);
// export const Firebase = getFirestore(app);
// firebase.initializeApp(firebaseConfig);
// var Firebase = firebase.firestore();
// export {Firebase};
