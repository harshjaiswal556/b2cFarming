import React from 'react'
import SearchIcon from '@mui/icons-material/Search';
export default function Search(props) {
    return(
      <SearchIcon style={{color:"white"}} />
    )
}